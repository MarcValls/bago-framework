# ESTADO_BAGO_ACTUAL

> **Nota de separación de capas:** este archivo describe el estado del pack BAGO como sistema,
> no el progreso funcional del repositorio externo intervenido.

## Proyecto activo

**CAJAFISICA** — `~/Desktop/BAGO_CAJAFISICA/`

Página web para medir y presentar packs `.bago`. Incluye escaneo automático de packs,
métricas de esfuerzo, validadores GO/KO en tiempo real y selector de carpeta nativo macOS.

## Estado del proyecto

- Bootstrap completado: git repo inicializado, commit inicial registrado.
- `bago-viewer` operativo en `http://localhost:5050`.
- Stack: Python + Flask.

## Modo predominante

[G] Generativo — proyecto en desarrollo activo

## Estado de validadores del pack

- `validate_manifest`: GO
- `validate_state`: GO
- `validate_pack`: GO (tras regeneración de TREE + CHECKSUMS)

## Última sesión

`SES-S4-2026-04-18-001` — system_change — cerrada (**Sprint 4 · Consolidación**)

- `docs/operation/AUDITORIA_COHERENCIA.md` — checklist de 8 bloques ejecutables con criterios PASS/FAIL y comandos bash.
- `docs/operation/MANTENIMIENTO.md` — guía operativa: cuándo regenerar TREE/CHECKSUMS, ciclo de vida de artefactos, qué no tocar, cronograma mínimo.
- `dist/source/BAGO_2_3_clean_sprint4_20260418_131747.zip` — paquete 2.3-clean actualizado (392K).
- `sprint_status.sprint_4: DONE` en `global_state.json`.
- TREE.txt y CHECKSUMS.sha256 regenerados. **validate_pack = GO pack.**

## Sprint status

| Sprint | Estado |
|--------|--------|
| sprint_1 | DONE |
| sprint_2 | DONE |
| sprint_3 | DONE |
| sprint_4 | **DONE** |

- Selector rápido `make WF` para enumerar workflows tácticos y su función.
- Nuevo workflow táctico `W6_IDEACION_APLICADA` para ideas contextualizadas, priorizadas por implementabilidad y estabilidad.
- Comando `./ideas`, `./ideas --detail N`, `./ideas --accept N` y `make ideas` para generar propuestas ordenadas, ampliarlas y aceptarlas antes de pasar a `W2`.
- Comando `./workflow-info W1` y `make workflow-info WF=W1` para inspeccionar una WF concreta con contexto, preguntas y prerequisitos.
- Lanzador mínimo ejecutable en `.bago/tools/launch_workflow_maestro.sh` y verificado en modo maestro y táctico.
- Atajo de raíz en `Makefile`: `make workflow`, `make WF`, `make wf` y `make workflow-tactical NAME=W6`.
- `README.md` de raíz ya presenta la entrada humana coherente al flujo BAGO y los comandos cortos.
- `.bago/README.md` quedó como entrada técnica interna con enlace de retorno al `README.md` de raíz.
- `AGENT_START.md` ya enlaza la ruta maestra de trabajo como referencia prioritaria de ejecución.
- Harness bajo `sandbox/` con perfil `restricted.sb`, runners `run.sh`, `run-vm.sh`, `run-vm-soak.sh`, `run-vm-matrix.sh` y `run-vm-regression.sh`, sonda `probe.py`, comparador `compare-vm-matrix-baseline.py`, promotor `promote-vm-matrix-baseline.sh`, helper guest `guest-run-bwrap.sh` y fixture `input/allowed.txt`.
- Informe de ejecución en `sandbox/runtime/last-report.json`.
- Informe de ejecución endurecida en `sandbox/runtime-vm/last-report-vm.json`.
- Informes por perfil y resumen de matriz en `sandbox/runtime-vm/matrix/`.
- Baseline congelado en `sandbox/baselines/vm-matrix/`.
- Política editable de umbrales por perfil en `sandbox/vm-regression-thresholds.json`.
- La sonda ya reporta métricas de CPU, RSS, duración por worker y artefactos generados para comparaciones de regresión.
- Archivo `.github/copilot-instructions.md` creado con comandos operativos reales, arquitectura de alto nivel y convenciones específicas del repo para futuras sesiones Copilot.
- Corregido wrapper `./ideas` para propagar argumentos CLI a `.bago/tools/emit_ideas.py` (`"$@"`), habilitando `--detail` y `--accept` desde el entrypoint de raíz.
- Ajustado `.bago/tools/emit_ideas.py` para eliminar la recomendación autorreferencial `Generador de ideas accionables` como idea top y evitar ciclos.
- Nuevo panel de configuración de perfil en `.bago/tools/personality_panel.py` con persistencia en `.bago/state/user_personality_profile.json` para personalidad, idioma y vocabulario contextual.
- Nuevo entrypoint de raíz `./personality-panel` y atajo `make personality` para abrir/usar el panel.
- Nuevo flujo guiado de vocabulario en `./personality-flow` (`make personality-flow`) para cargar términos del círculo pequeño sin usar flags.
- Guard de contexto de repositorio en `.bago/tools/repo_context_guard.py` integrado en el launcher para forzar `W1/repo-first` si hay cambio de repo y evitar bucles de estado heredado.
- Paquete ZIP generado del BAGO actualizado en `dist/source/BAGO_2_3_clean_repo_guard_20260415_204934.zip`.
- Entrypoints de raíz restaurados: `./ideas`, `./workflow-info`, `./personality-panel`, `./personality-flow` y `Makefile` con atajos `workflow`, `WF`, `workflow-tactical`, `workflow-info`, `ideas`, `repo-context-check` y `repo-context-sync`.
- **[SES-BOOTSTRAP-20260416-001]** TREE.txt y CHECKSUMS.sha256 regenerados tras mismatch de fingerprint detectado en repo_context_guard.
- **[SES-BOOTSTRAP-20260416-001]** Nuevo tool `./stability-summary` (`make stability-summary`) implementado para resumen único de estabilidad (idea 2 de W2).
- **[SES-BOOTSTRAP-20260416-001]** `Makefile` actualizado con target `stability-summary`.
- **[SES-BOOTSTRAP-20260416-001]** TREE.txt (387 entradas) y CHECKSUMS.sha256 (317 entradas) realineados; `validate_pack` = GO.
- **[SES-GATE-20260416-002]** Gate canónico implementado en `emit_ideas.py`: si `validate_pack` o `validate_state` fallan (o smoke está disponible pero en KO), el selector bloquea con `GATE KO` y `exit 1`. Métrica cumplida: ninguna idea avanza si validadores canónicos no están en verde.
- **[SES-GATE-20260416-002]** CHECKSUMS.sha256 (317 entradas) regenerado para incluir la versión actualizada de `emit_ideas.py`.
- **[SES-BASELINE-20260416-003]** Gate métrica en `--accept`: si la idea seleccionada no declara campo `metric` no vacío, `./ideas --accept N` rechaza con `exit 1` y mensaje explicativo. Métrica cumplida: ninguna idea puede aceptarse sin una mejora trazable declarada. CHECKSUMS.sha256 regenerado (317 entradas).
- **[SES-README-20260416-004]** `README.md` raíz y `.bago/README.md` alineados con el selector real: añadido `./stability-summary` al flujo de arranque, documentados gates canónico/smoke/métrica en tabla, explicados flags de `./ideas` con sus condiciones de bloqueo. Métrica cumplida: README y selector describen la misma ruta de arranque sin ambigüedades.
- Workflow maestro operativo en `.bago/workflows/WORKFLOW_MAESTRO_BAGO.md`.
- Índice táctico en `.bago/workflows/WORKFLOWS_INDEX.md` para navegar `W1..W6`.
- Selector rápido `make WF` para enumerar workflows tácticos y su función.
- Nuevo workflow táctico `W6_IDEACION_APLICADA` para ideas contextualizadas, priorizadas por implementabilidad y estabilidad.
- Comando `./ideas`, `./ideas --detail N`, `./ideas --accept N` y `make ideas` para generar propuestas ordenadas, ampliarlas y aceptarlas antes de pasar a `W2`.
- Comando `./workflow-info W1` y `make workflow-info WF=W1` para inspeccionar una WF concreta con contexto, preguntas y prerequisitos.
- Lanzador mínimo ejecutable en `.bago/tools/launch_workflow_maestro.sh` y verificado en modo maestro y táctico.
- Atajo de raíz en `Makefile`: `make workflow`, `make WF`, `make wf` y `make workflow-tactical NAME=W6`.
- `README.md` de raíz ya presenta la entrada humana coherente al flujo BAGO y los comandos cortos.
- `.bago/README.md` quedó como entrada técnica interna con enlace de retorno al `README.md` de raíz.
- `AGENT_START.md` ya enlaza la ruta maestra de trabajo como referencia prioritaria de ejecución.
- Harness bajo `sandbox/` con perfil `restricted.sb`, runners `run.sh`, `run-vm.sh`, `run-vm-soak.sh`, `run-vm-matrix.sh` y `run-vm-regression.sh`, sonda `probe.py`, comparador `compare-vm-matrix-baseline.py`, promotor `promote-vm-matrix-baseline.sh`, helper guest `guest-run-bwrap.sh` y fixture `input/allowed.txt`.
- Informe de ejecución en `sandbox/runtime/last-report.json`.
- Informe de ejecución endurecida en `sandbox/runtime-vm/last-report-vm.json`.
- Informes por perfil y resumen de matriz en `sandbox/runtime-vm/matrix/`.
- Baseline congelado en `sandbox/baselines/vm-matrix/`.
- Política editable de umbrales por perfil en `sandbox/vm-regression-thresholds.json`.
- La sonda ya reporta métricas de CPU, RSS, duración por worker y artefactos generados para comparaciones de regresión.
- Archivo `.github/copilot-instructions.md` creado con comandos operativos reales, arquitectura de alto nivel y convenciones específicas del repo para futuras sesiones Copilot.
- Corregido wrapper `./ideas` para propagar argumentos CLI a `.bago/tools/emit_ideas.py` (`"$@"`), habilitando `--detail` y `--accept` desde el entrypoint de raíz.
- Ajustado `.bago/tools/emit_ideas.py` para eliminar la recomendación autorreferencial `Generador de ideas accionables` como idea top y evitar ciclos.
- Nuevo panel de configuración de perfil en `.bago/tools/personality_panel.py` con persistencia en `.bago/state/user_personality_profile.json` para personalidad, idioma y vocabulario contextual.
- Nuevo entrypoint de raíz `./personality-panel` y atajo `make personality` para abrir/usar el panel.
- Nuevo flujo guiado de vocabulario en `./personality-flow` (`make personality-flow`) para cargar términos del círculo pequeño sin usar flags.
- Guard de contexto de repositorio en `.bago/tools/repo_context_guard.py` integrado en el launcher para forzar `W1/repo-first` si hay cambio de repo y evitar bucles de estado heredado.
- Paquete ZIP generado del BAGO actualizado en `dist/source/BAGO_2_3_clean_repo_guard_20260415_204934.zip`.
- Entrypoints de raíz restaurados: `./ideas`, `./workflow-info`, `./personality-panel`, `./personality-flow` y `Makefile` con atajos `workflow`, `WF`, `workflow-tactical`, `workflow-info`, `ideas`, `repo-context-check` y `repo-context-sync`.

## Decisiones congeladas

- Mantener `.bago/AGENT_START.md` como entrada oficial del arranque.
- Tratar este repositorio como consolidado oficial limpio `2.3-clean` mientras `pack.json` y `global_state.json` sigan alineados.

## Incidencias abiertas

- `sandbox-exec` es un mecanismo legado de macOS; sirve para validación local, pero no sustituye una VM o contenedor para aislamiento fuerte.
- En la variante Linux se desactivan `blocked_exec` y `blocked_read` por las limitaciones prácticas del sandbox interno con `bubblewrap` en este guest.
- Lima sigue siendo sensible al espacio libre del host; fue necesario limpiar cachés del usuario para recuperar ~8 GiB y estabilizar la VM.
- Los gates de regresión ahora dependen de una política configurable por perfil (`smoke`, `stress`, `soak`); cualquier ajuste debe preservarse coherente con el baseline congelado.
- Arranque BAGO revalidado: `TREE.txt` y `CHECKSUMS.sha256` se realinearon con el árbol real de `.bago/`.

## Siguiente paso

- Idea 1 (Handoff -> W2): ya estaba implementada; verificado en esta sesión que `./ideas --accept 1` emite handoff completo ✓.
- Idea 2 (Resumen único de estabilidad): implementada en sesión anterior → `./stability-summary` y `make stability-summary` ✓.
- **Idea 3 (Gate seguro antes de implementar): implementada en esta sesión ✓** — `emit_ideas.py` bloquea con `GATE KO + exit 1` si `validate_pack`, `validate_state` o smoke (cuando disponible) no están en verde.
- Próximo paso: ejecutar `./ideas --accept 4` (Ideas orientadas a baseline) para continuar con W2 en la siguiente sesión.
- Usar `make stability-summary` como gate previo a cualquier nueva implementación.
- Cargar términos reales del usuario en `./personality-panel --add-term ... --meaning ... --example ...` para adaptar vocabulario de círculo pequeño.
- Usar `./personality-flow` para registrar términos de manera guiada cuando se quiera evitar comandos largos.
- Ejecutar `make repo-context-sync` tras migrar/copiar BAGO a un repo nuevo para fijar el contexto base.
- Repetir `make personality-flow` introduciendo términos reales para completar la personalización de vocabulario.
- Revisar si `copilot-instructions.md` necesita ampliar cobertura para áreas concretas (por ejemplo sandbox o validadores).
- Definir el objetivo técnico prioritario de esta sesión para completar la salida de `W1_COLD_START`.
- Usar `make WF` para elegir workflow táctico por función.
- Usar `make workflow-tactical NAME=W6` cuando se quiera ideación aplicada antes de implementar.
- Usar `make ideas` o `./ideas` para obtener propuestas contextualizadas antes de decidir implementación.
- Usar `./workflow-info W1` para preparar configuración humana de un workflow concreto.
- Usar `./sandbox/run.sh` para validación rápida local, `./sandbox/run-vm.sh` para regresión endurecida puntual, `./sandbox/run-vm-soak.sh` para larga duración, `./sandbox/run-vm-matrix.sh` para perfiles reproducibles y `./sandbox/run-vm-regression.sh` para comparación automática contra baseline.
- Última verificación rápida hecha: `./sandbox/run-vm-regression.sh --profiles smoke` en verde contra el baseline usando `sandbox/vm-regression-thresholds.json`.

## Cierre de sesión

- Estado: cerrada y retomable.
- Workflow cerrado: `W5_CIERRE_Y_CONTINUIDAD`.
- Retomar por: `make WF` y elegir el táctico adecuado.
- Si aparece un fallo nuevo, cambiar a `W4_DEBUG_MULTICAUSA`.
- Si el objetivo es abrir trabajo nuevo desde cero, cambiar a `W1_COLD_START`.

## Última actualización

- fecha: 2026-04-16T14:14:58Z
- nota: Bootstrap autónomo SES-BOOTSTRAP-20260416-001; repo_context_guard mismatch→synced; TREE.txt+CHECKSUMS regenerados; validate_pack=GO; idea 2 implementada (stability-summary tool).
- fecha: 2026-04-16 16:01:00 CEST
- nota: modo autónomo reactivado; se restauraron entrypoints de BAGO en raíz y se volvió a alinear el acceso operativo (`./ideas`, `./workflow-info`, `make workflow-tactical NAME=W1/W2`).
- fecha: 2026-04-16 15:44:00 CEST
- nota: W2 ejecutado sobre idea 4; el selector quedó en modo baseline limpio con filtro por bajo riesgo y métrica explícita.
- fecha: 2026-04-16 04:19:07 CEST
- nota: `./ideas` ahora sale como lista plana enumerada y descrita.
- fecha: 2026-04-16 04:14:54 CEST
- nota: `./ideas` quedó en el formato duro final que pediste.
- fecha: 2026-04-16 04:10:18 CEST
- nota: `./ideas` quedó alineado con el formato de bloque que pediste.
- fecha: 2026-04-16 04:07:04 CEST
- nota: `./ideas` quedó con bloques reforzados para que cada idea destaque en terminal.
- fecha: 2026-04-16 04:04:48 CEST
- nota: `./ideas` quedó en formato bloque por idea para terminal.
- fecha: 2026-04-16 04:03:23 CEST
- nota: `./ideas` ya muestra una descripción separada para cada idea.
- fecha: 2026-04-16 04:02:32 CEST
- nota: `./ideas` ahora muestra un resumen total antes de las secciones.
- fecha: 2026-04-16 04:00:44 CEST
- nota: la regla de `respaldo` al caer por debajo de 5 ahora tiene prueba dedicada.
- fecha: 2026-04-16 03:59:53 CEST
- nota: `./ideas` ahora expone recuento por sección y oculta `respaldo` vacío.
- fecha: 2026-04-16 03:58:58 CEST
- nota: `./ideas` solo rellena `respaldo` si `contextuales` no llega al mínimo de 5.
- fecha: 2026-04-16 03:57:57 CEST
- nota: `./ideas` ya muestra secciones `contextuales` y `respaldo`.
- fecha: 2026-04-16 03:55:02 CEST
- nota: `./ideas` quedó acotado a un rango de 5 a 20 ideas.
- fecha: 2026-04-16 03:52:54 CEST
- nota: `./ideas --accept N` ya emite handoff estructurado para W2.
- fecha: 2026-04-16 03:49:07 CEST
- nota: bootstrap oficial revalidado en esta sesión; `repo_context_guard` = `match`.
- fecha: 2026-04-15 20:49:34 CEST
- fecha: 2026-04-15 20:11:57 CEST
- fecha: 2026-04-15 19:48:57 CEST
- fecha: 2026-04-15 19:38:11 CEST
- fecha: 2026-04-15 19:18:27 CEST
- fecha: 2026-04-15 19:09:27 CEST
- fecha: 2026-04-15 19:07:42 CEST
- fecha: 2026-04-15 19:03:17 CEST
- fecha: 2026-04-15 18:46:38 CEST
- fecha: 2026-04-15 18:43:19 CEST
- fecha: 2026-04-15 16:59:49 CEST
- fecha: 2026-04-15 17:04:03 CEST
- fecha: 2026-04-15 17:09:31 CEST
- fecha: 2026-04-15 17:29:15 CEST
- fecha: 2026-04-15 16:58:32 CEST
- fecha: 2026-04-15 16:54:29 CEST
- fecha: 2026-04-15 16:47:27 CEST
- fecha: 2026-04-15 16:42:16 CEST
- autor/agente: Codex / MAESTRO_BAGO
